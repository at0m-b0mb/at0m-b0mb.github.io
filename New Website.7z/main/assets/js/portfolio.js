(function () {
    $("button.cta").on('click', function () {
        window.location.href = "https://linktr.ee/HackProKP";
    });
})();